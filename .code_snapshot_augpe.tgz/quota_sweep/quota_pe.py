"""Quota sweep (Experiment 2): MAPLE PE with the blind-attribute quota, for one lambda.

Round 0 reuses the pre-vote pool from gen_round0.py (same for every lambda, so runs
differ only in selection). Then for t = 0..T:
  vote (MAPLE: every private point votes for its nearest candidate under phi, + N(0, sigma^2))
  -> quota selection on the blind attributes B (quota_sweep/quota.py), lambda_t from the schedule
  -> evaluate the K survivors (JSD per attribute vs the test set, MAUVE vs the test set)
  -> VARIATION_API x L on the survivors (MAPLE's prompt) -> next candidates.
Labels used *inside* the loop come from --loop_annotator; evaluation always uses
--eval_annotator (default qwen = ground truth for now). word_count is always measured.

Vote embedding: --vote_emb t5 (default, MAPLE's sentence-t5) or ft (the fine-tuned BiomedBERT
from vote_embedding/train_embedder.py, --vote_emb_path). The vote uses it for both the private
points and the candidates. MAUVE always stays on sentence-t5: with ft, t5 features are computed
for the K survivors only; with t5 the old code path (Xs = Xc[sel]) is unchanged.

One GPU per run: vLLM (generation + Qwen annotation share one engine) and sentence-t5.
Resumable: finished rounds are reloaded and the run continues after the last one.

Example:
    CUDA_VISIBLE_DEVICES=1 python quota_sweep/quota_pe.py --maple_dir $PE_DATA/MAPLE \
        --pool_csv $PE_DATA/round0/eps4.0/pool.csv --eps 4.0 --lam 0.5 \
        --test_ref $PE_DATA/quota_sweep/test_ref_qwen.csv --out $PE_DATA/quota_sweep/eps4.0/qwen/lam0.5
"""
import argparse
import importlib.util
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial.distance import jensenshannon

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
from blindness.schema import BIORXIV_SCHEMA, clean_labels  # noqa: E402
from quota_sweep.annotators import ATTRS, CONTENT, make_annotator  # noqa: E402
from quota_sweep.quota import (assign_cells, build_cell_space, build_marginals, cell_keys,  # noqa: E402
                               marginal_jsd, select, select_raked)
from vote_correction import jsd, nearest_pool_index  # noqa: E402

METADATA = CONTENT + ["word_count"]   # MAPLE's 9 metadata columns (word_count = requested length)
# MAPLE main_experiment.sh, MAPLE.py runs: eps -> (PE_T, noise multiplier)
EPS_SETTINGS = {"4.0": (4, 2.5787580697142025), "2.0": (4, 4.7482491352519505), "1.0": (2, 6.869194837509232),
                "inf": (9, 0.0)}


def lam_at(t, T, lam, schedule):
    return lam if schedule == "constant" or T == 0 else lam * t / T


def aim_target_labels(aim_df, blind):
    lab = clean_labels(aim_df, [a for a in blind if a != "word_count"])
    if "word_count" in blind:
        lab["word_count"] = ((aim_df["word_count"].astype(float) / 50).round() * 50).astype(int).astype(str).to_numpy()
    return lab


def load_mauve(maple_dir):
    path = Path(maple_dir) / "biorxiv" / "utility_eval" / "compute_mauve.py"
    spec = importlib.util.spec_from_file_location("maple_compute_mauve", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.compute_mauve


class Embedder:
    """sentence-t5-base at max_seq_length 1024. Attention memory grows with batch x 1024^2:
    batch 256 needs ~12 GB and OOMs next to vLLM, batch 32 needs ~1.5 GB."""

    def __init__(self, batch=32):
        from sentence_transformers import SentenceTransformer
        self.m = SentenceTransformer("sentence-t5-base", device="cuda")
        self.m.max_seq_length = 1024
        self.batch = batch

    def __call__(self, texts):
        import torch
        texts = list(texts)
        order = np.argsort([len(t) for t in texts])          # length-sorted batches: less padding
        out = np.zeros((len(texts), self.m.get_sentence_embedding_dimension()), np.float32)
        for i in range(0, len(order), self.batch):
            idx = order[i:i + self.batch]
            out[idx] = self.m.encode([texts[j] for j in idx], batch_size=self.batch,
                                     convert_to_numpy=True, show_progress_bar=False)
        torch.cuda.empty_cache()
        return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--maple_dir", required=True)
    p.add_argument("--pool_csv", required=True, help="round-0 candidates before the vote (gen_round0.py)")
    p.add_argument("--eps", default="4.0", choices=list(EPS_SETTINGS))
    p.add_argument("--lam", type=float, required=True, help="lambda (under --schedule linear: its last-round value)")
    p.add_argument("--schedule", default="constant", choices=["constant", "linear"],
                   help="constant: lambda_t = lam; linear: lambda_t = lam * t / T (0 at round 0)")
    p.add_argument("--blind", nargs="+", default=["word_count", "sample_size", "dominant_data_type"])
    p.add_argument("--cell_mode", default="raking", choices=["raking", "joint"],
                   help="raking (default): quotas from one-way marginals of B via iterative proportional fitting, "
                        "no merged cells; joint: top max_cells joint cells + __other__ (first version)")
    p.add_argument("--max_cells", type=int, default=30, help="joint mode only")
    p.add_argument("--loop_annotator", default="qwen", choices=["qwen", "inherited", "classifier"])
    p.add_argument("--eval_annotator", default="qwen", choices=["qwen"])
    p.add_argument("--classifier_spec", default=None, help="best_annotator.json, for --loop_annotator classifier")
    p.add_argument("--test_ref", required=True, help="test set with eval-annotator labels (created if missing)")
    p.add_argument("--K", type=int, default=2000)
    p.add_argument("--L", type=int, default=6, help="variations per survivor (MAPLE PE_L_random)")
    p.add_argument("--T", type=int, default=None, help="override MAPLE's number of PE rounds for this eps")
    p.add_argument("--noise", type=float, default=None, help="override MAPLE's noise multiplier for this eps")
    p.add_argument("--model_id", default="Qwen/Qwen2.5-7B-Instruct")
    p.add_argument("--gpu_mem", type=float, default=0.5,
                   help="vLLM gpu_memory_utilization; the rest is for sentence-t5 + the classifier annotator")
    p.add_argument("--emb_batch", type=int, default=32, help="sentence-t5 (and ft vote embedding) batch size")
    p.add_argument("--vote_emb", default="t5", choices=["t5", "ft"],
                   help="t5: sentence-t5 (MAPLE); ft: fine-tuned BiomedBERT (vote_embedding/). MAUVE stays on t5")
    p.add_argument("--vote_emb_path", default=None,
                   help="trained ft embedder (default $PE_DATA/vote_embedding/eps<eps>/normsoftmax)")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--out", required=True)
    p.add_argument("--prep_only", action="store_true", help="only build --test_ref (labels of the test set), then exit")
    args = p.parse_args()

    T, sigma = EPS_SETTINGS[args.eps]
    T = args.T if args.T is not None else T
    sigma = args.noise if args.noise is not None else sigma
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    data_root = Path(os.environ.get("PE_DATA", "."))
    if args.vote_emb == "ft" and args.vote_emb_path is None:
        args.vote_emb_path = str(data_root / "vote_embedding" / f"eps{args.eps}" / "normsoftmax")
    (out / "config.json").write_text(json.dumps({**vars(args), "T": T, "sigma": sigma}, indent=2))
    bio = Path(args.maple_dir) / "biorxiv"

    # --- MAPLE pieces ---
    sys.path.insert(0, str(bio / "MAPLE"))
    from MAPLE import create_review_variation_prompt  # noqa: E402
    from util import SuppressChineseLogitsProcessor, set_seed  # noqa: E402
    from transformers import AutoTokenizer
    from vllm import LLM, SamplingParams
    set_seed(42 + args.seed)
    rng = np.random.default_rng(args.seed)
    tok = AutoTokenizer.from_pretrained(args.model_id)
    llm = LLM(model=args.model_id, max_model_len=32768, gpu_memory_utilization=args.gpu_mem,
              logits_processors=[SuppressChineseLogitsProcessor], seed=args.seed)
    var_sp = SamplingParams(temperature=1.0, top_p=0.95, max_tokens=1024)

    loop_ann = make_annotator(args.loop_annotator, args.maple_dir, llm=llm, model=args.model_id,
                              classifier_spec=args.classifier_spec)
    eval_ann = loop_ann if args.eval_annotator == args.loop_annotator else \
        make_annotator(args.eval_annotator, args.maple_dir, llm=llm, model=args.model_id)
    emb = Embedder(args.emb_batch)  # sentence-t5: MAUVE always; also the vote with --vote_emb t5
    vemb = emb
    if args.vote_emb == "ft":
        from vote_embedding.embedder import FTEmbedder
        vemb = FTEmbedder(args.vote_emb_path, batch=args.emb_batch, cache_dir=str(data_root / "cache"))
        print(f"vote embedding: {vemb.name} from {args.vote_emb_path}", flush=True)
    compute_mauve = load_mauve(args.maple_dir)

    # --- private voters, AIM target over cells of B, test reference ---
    from blindness.embed import embed
    priv = pd.read_csv(bio / "biorxiv_train_metadata.csv")
    priv = priv[priv["text"].notna()].reset_index(drop=True)
    if args.vote_emb == "t5":
        X_priv = embed(priv["text"].astype(str).tolist(), "sentence-t5-base", 1024, batch_size=args.emb_batch,  # 256 OOMs next to vLLM on H100 80GB
                       cache_dir=str(data_root / "cache"))
    else:
        X_priv = vemb(priv["text"].astype(str).tolist())  # cached under $PE_DATA/cache
    aim = pd.read_csv(bio / (f"biorxiv_train_metadata_aim_eps{float(args.eps):.1f}_(1,9).csv"
                             if args.eps != "inf" else "biorxiv_train_metadata.csv"))
    aim_lab = aim_target_labels(aim, args.blind)
    p_marg = build_marginals(aim_lab, args.blind)
    kept, p_hat = build_cell_space(aim_lab, args.blind, args.max_cells) if args.cell_mode == "joint" else (None, None)
    (out / "cells.json").write_text(json.dumps({"blind": args.blind, "cell_mode": args.cell_mode,
                                                "p_marg": p_marg, "p_hat": p_hat}, indent=2))

    test_path = Path(args.test_ref)
    if test_path.exists():
        test = pd.read_csv(test_path)
    else:
        test = pd.read_csv(bio / "biorxiv_test_metadata.csv")
        test = test[test["text"].notna()].reset_index(drop=True)
        tl = eval_ann.label(test)
        for a in ATTRS:
            test[f"ref_{a}"] = tl[a]
        test_path.parent.mkdir(parents=True, exist_ok=True)
        test.to_csv(test_path, index=False)
    if args.prep_only:
        print(f"test reference ready: {test_path} ({len(test)} rows)"); return
    ref = {a: test[f"ref_{a}"].astype(str).to_numpy() for a in ATTRS}
    gem = clean_labels(test, CONTENT)  # MAPLE's Gemini labels of the test set, secondary reference
    X_test = emb(test["text"].astype(str).tolist())

    # --- resume ---
    mpath = out / "metrics.jsonl"
    done = [json.loads(l) for l in mpath.read_text().splitlines()] if mpath.exists() else []
    start = len(done)
    if start > T:
        print("already finished"); return
    if start == 0:
        cand = pd.read_csv(args.pool_csv)
        cand = cand[cand["text"].notna()].reset_index(drop=True)
    else:
        cand = None  # rebuilt below from the last survivors
        sel_df = pd.read_csv(out / f"round_{start - 1}.csv")
        print(f"resuming after round {start - 1}", flush=True)

    def variations(sel_df):
        var = pd.concat([sel_df[METADATA + ["text"]]] * args.L, ignore_index=True)
        prompts = [tok.apply_chat_template(create_review_variation_prompt(r[METADATA].to_dict(), r["text"], []),
                                           tokenize=False, add_generation_prompt=True) for _, r in var.iterrows()]
        outs = llm.generate(prompts, var_sp, use_tqdm=False)
        var["text"] = [o.outputs[0].text for o in outs]
        return pd.concat([sel_df[METADATA + ["text"]], var], ignore_index=True)

    for t in range(start, T + 1):
        t0 = time.time()
        if cand is None:
            cand = variations(sel_df)
        cand = cand[cand["text"].astype(str).str.strip() != ""].reset_index(drop=True)
        # vote
        Xc = vemb(cand["text"].astype(str).tolist())
        hist = np.bincount(nearest_pool_index(X_priv, Xc), minlength=len(cand)).astype(float)
        if sigma:
            hist = hist + rng.normal(scale=sigma, size=len(hist))
        # quota selection on loop labels
        lab = loop_ann.label(cand)
        lam_t = lam_at(t, T, args.lam, args.schedule)
        if args.cell_mode == "joint":
            cells = assign_cells(lab, args.blind, kept)
            sel, info = select(hist, cells, p_hat, lam_t, args.K)
        else:
            cells = cell_keys(lab, args.blind)
            sel, info = select_raked(hist, lab, args.blind, p_marg, lam_t, args.K)
        sel_df = cand.iloc[sel].reset_index(drop=True)
        sel_df["vote"] = hist[sel]
        sel_df["cell"] = cells[sel]
        for a in ATTRS:
            sel_df[f"loop_{a}"] = lab[a][sel]
        # evaluate survivors
        ev = eval_ann.label(sel_df)
        for a in ATTRS:
            sel_df[f"eval_{a}"] = ev[a]
        Xs = Xc[sel] if args.vote_emb == "t5" else emb(sel_df["text"].astype(str).tolist())  # MAUVE on t5
        m = dict(round=t, lam_t=lam_t, n_candidates=len(cand), shortfall=info["shortfall"], moved=info["moved"],
                 mauve=float(compute_mauve(p_features=X_test, q_features=Xs).mauve))
        for a in ATTRS:
            m[f"jsd_{a}"] = jsd(ev[a], ref[a])
        for a in CONTENT:
            m[f"jsd_gemini_{a}"] = jsd(ev[a], gem[a])
        m["jsd_mean"] = float(np.mean([m[f"jsd_{a}"] for a in ATTRS]))
        m["jsd_blind_mean"] = float(np.mean([m[f"jsd_{a}"] for a in args.blind]))
        m["jsd_other_mean"] = float(np.mean([m[f"jsd_{a}"] for a in ATTRS if a not in args.blind]))
        for src, labs in [("loop", lab), ("eval", ev)]:
            sl = {a: (labs[a][sel] if src == "loop" else labs[a]) for a in args.blind}
            mj = marginal_jsd(sl, args.blind, p_marg)
            m[f"marg_jsd_vs_phat_{src}_labels"] = float(np.mean(list(mj.values())))
            if args.cell_mode == "joint":
                cats = sorted(p_hat)
                lc = assign_cells(sl, args.blind, kept)
                m[f"cell_jsd_vs_phat_{src}_labels"] = float(jensenshannon(
                    np.array([np.mean(lc == c) for c in cats]), np.array([p_hat[c] for c in cats])))
        m["seconds"] = round(time.time() - t0, 1)
        sel_df.to_csv(out / f"round_{t}.csv", index=False)
        with open(mpath, "a") as f:
            f.write(json.dumps(m) + "\n")
        print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in m.items()
                          if k in ("round", "lam_t", "mauve", "jsd_mean", "jsd_blind_mean", "jsd_other_mean",
                                   "moved", "shortfall", "seconds")}), flush=True)
        cand = None
    (out / "DONE").write_text(time.strftime("%F %T"))


if __name__ == "__main__":
    # vLLM keeps an engine subprocess alive; after an exception the parent would wait on it
    # forever (seen: OOM at 12:17, process still there 4 h later). Exit hard either way.
    import traceback
    code = 0
    try:
        main()
    except SystemExit as e:
        code = int(e.code or 0)
    except BaseException:
        traceback.print_exc()
        code = 1
    finally:
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(code)
